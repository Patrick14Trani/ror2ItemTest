# ror2ItemTest
This will be a quick test to see if I can create an item or items for Risk of Rain 2.
