# Vestiges of the Old Queen
[Demo](https://youtu.be/wVAetIBy6LQ)

Implements three items:
- N'kuhana's Providence (Lunar)
- The Crown Jewel (Common)
- The Old Shield (Uncommon)